clear all;
cd ('C:\Users\Magic\Desktop\ABC_MATLAB_DATA_EXPLORER');

%--------------------------------------------------------------------------
%Load all .xl* files in directory
%assumes row labels, first of which is abc identifier
%assumes column labels = 'unique' variable names
data_files_to_load = dir('*.xl*')
for f = 1:length(data_files_to_load)

    %load database from xls(x) file
    [d s] = xlsread(data_files_to_load(f).name)
    column_labels = transpose(s(1,:));
    column_labels = matlab.lang.makeValidName(column_labels);
    row_labels = s(:,1);
    data = d;

    %enter each row into a structure
    for i = 1:size(column_labels,1)-1
        column_name = char(column_labels(i+1));
        database.(column_name) = data(:,i)
    end
end

%--------------------------------------------------------------------------
%PLACEHOLDER
%These will be chosen using a yet to be created GUI
chosenStrings = [column_labels(220), column_labels(3), column_labels(4)]
   
%--------------------------------------------------------------------------
%PLACEHOLDER --> use rmoutliers, remove outliers (user chooses SD, method)

%--------------------------------------------------------------------------
%PLACEHOLDER --> use partialcorr, choose which variables to control for

%--------------------------------------------------------------------------
%Create corr_data = data structure just with chosen items
%Remove particiapnts with NAN in any chosen variable (be careful may really reduce if
%many variables!
idx = zeros(size(data,1),1)
for choice = 1:length(chosenStrings)
    column_name = char(chosenStrings(choice));
    corr_data(:,choice) =  database.(column_name)
    %and keep track of locations where one or more variables have a NAN...
    idx = idx + isnan(corr_data(:,choice));
    idx(idx>1) = 1;
end

%--------------------------------------------------------------------------
%Create correlation matrix from elements chosen with row and column names
correlationMatrix = [];
for i = 1:length(chosenStrings)
    for j = 1:length(chosenStrings)
    correlationMatrix(i,j) = corr(corr_data(logical(~idx),i), corr_data(logical(~idx),j));
    end
end
N = length(corr_data(logical(~idx)));
Rthresh = abs(2/sqrt(N));
fprintf('For N(%g), correlations are significant if [abs(r) > %f]  :',N,Rthresh);

%Create correlation tavle with asterisks for significant values
correlationStringMatrix = string(correlationMatrix);
for i = 1:length(chosenStrings)
    for j = 1:length(chosenStrings)
        if((correlationMatrix(i,j) < -Rthresh | correlationMatrix(i,j) > Rthresh) & correlationMatrix(i,j) < 0.99999999)
        correlationStringMatrix(i,j) = strcat("*" ,correlationStringMatrix(i,j));    
        end
    end
end
%add row and column names
correlationTable = array2table(string(correlationStringMatrix));
correlationTable.Properties.VariableNames = chosenStrings;
correlationTable.Properties.RowNames = chosenStrings;
%display table
correlationTable
    