import csv
def ipaqContinous(row,truncate = False):
	"""
	Calculates the MET-Minutes 
	"""
	if truncate:
		walkingMET = min(row[8]*60+row[9],240)*row[7] * 3.3
		moderateMET = min(row[5]*60+row[6],240)*row[4] * 4.0
		vigorousMET = min(row[2]*60+row[3],240)*row[1] * 8.0
	else:
		walkingMET = 3.3 * ((row[8] * 60) + row[9]) * row[7]
		moderateMET = 4.0 * ((row[5] * 60) + row[6]) * row[4]
		vigorousMET = 8.0 * ((row[2] * 60) + row[3]) * row[1]
	return([walkingMET, moderateMET, vigorousMET])

def cleanData(data):
	cleanedData = []
	for row in data:
		cleanRow = []
		colID = 0
		for datum in row:
			if datum == '':
				cleanRow.append(0)
			elif "ABC" in datum:
				cleanRow.append(datum)
			else:
				if colID == 2 or colID == 5 or colID == 8:
					if float(datum) > 16:
						cleanRow.append(16)
				elif colID == 1 or colID == 4 or colID == 7:
					if float(datum) > 7:
						cleanRow.append(7)
				cleanRow.append(float(datum))
			colID += 1
		cleanedData.append(cleanRow)
	return cleanedData

def catagorizeIpaq(row):
	met = ipaqContinous(row, truncate=True)
	# Vigourous days >= 3 (a)
	if(row[1] >= 3):
		#Vigourous time >= 20 (e)
		if(row[2]* 60 + row[3] >= 20):
			#Vigorous days >= 3 AND Vig METmins >= 1500 (f)
			if(row[1] >= 3 and met[2] >= 1500):
				return(3)
			#Days of Walking + Moderate days + vigorous days >= 7 AND sum of metMins >= 3000 (g)
			elif(row[7] + row[4] + row[1] >= 7 and sum(met) >= 3000):
				return(3)
			else:
				return(2)
		else:
			#Total days of moderate + walking days >= 5 (b)
			if(row[7] + row[4] >= 5):
				#Moderate time + walktime >= 30 (c)
				if(row[5] * 60 + row[6] + row[8] * 60 + row[9] >= 30):
					return(2)
				#Days of walking + moderate days + vigorous days >= 5 AND sum of metMins >= 600 (d)
				elif(row[7] + row[4] + row[1] >= 5 and sum(met) >= 600):
					return(2)
				else:
					return(1)
			else:
				return(1)
	
	#Total days of moderate + walking days >= 5 (b)
	if(row[7] + row[4] >= 5):
		#Moderate time + walktime >= 30 (c)
		if(row[5] * 60 + row[6] + row[8] * 60 + row[9] >= 30):
			return(2)
		#Days of walking + moderate days + vigorous days >= 5 AND sum of metMins >= 600 (d)
		elif(row[7] + row[4] + row[1] >= 5 and sum(met) >= 600):
			return(2)
		else:
			return(1)
	else:
		return(1)

def main():
    #input file
    with open('/Volumes/Crucial X6/ABC/ABCTools/IPAQ/CNABC_IPAQ_numbers.csv', 'r') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)
        data = list(reader)
        data = cleanData(data)
        #output file
        with open('cnabcout.csv', 'w') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['ID', 'truncated', 'nonTruncated', 'catagory'])
            for row in data:
                trunc = sum(ipaqContinous(row,truncate=True))
                nonTrunc = sum(ipaqContinous(row,truncate=False))
                writer.writerow([row[0], trunc, nonTrunc,catagorizeIpaq(row)])

if __name__ == "__main__":
    main()